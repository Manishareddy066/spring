package orm.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import orm.models.Course;

public interface CourseRepository extends JpaRepository<Course, Long> {

}