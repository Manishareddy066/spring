package orm.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import orm.models.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {

}