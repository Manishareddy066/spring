package orm;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import orm.models.Student;
import orm.services.StudentService;

@Controller

public class StudentController {

	StudentService stdService;

	@Autowired

	public StudentController(StudentService ss) {

		stdService = ss;

	}

	/**
	 * 
	 * selects the Add New Employee view to render by returning its name.
	 * 
	 */

	@RequestMapping(value = "/stdlist", method = RequestMethod.GET)

	public String getAllEmployees(Model model) {

		System.out.println("Students List JSP Requested");

		// get all employees from DAO

		List<Student> stdList = stdService.findAll();

		// set it to the model

		model.addAttribute("slist", stdList);

		// call the view

		return "stdlist";

	}

	@RequestMapping(value = "/enroll", method = RequestMethod.GET)

	public String saveNewStudent(Model model) {

		System.out.println("Enroll Students in Courses");

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		StudentService studentService = context.getBean(StudentService.class);

		studentService.enrollStudentInCourse();

		return "enrollsuccess";

	}

	/*
	 * 
	 * Above method is supposed to be a post call like this
	 * 
	 * 
	 * 
	 * @RequestMapping(value = "/enroll", method = RequestMethod.POST)
	 * 
	 * public String saveNewStudent(Student std, Model model) {
	 * 
	 * 
	 * 
	 * System.out.println("Enroll Students in Courses");
	 * 
	 * 
	 * 
	 * ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
	 * 
	 * 
	 * 
	 * StudentService studentService = context.getBean(StudentService.class);
	 * 
	 * 
	 * 
	 * 
	 * 
	 * studentService.enrollStudentInCourse(<std>);
	 * 
	 * return "enrollsuccess";
	 * 
	 * }
	 * 
	 */

}