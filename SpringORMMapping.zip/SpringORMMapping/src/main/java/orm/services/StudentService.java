package orm.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import orm.models.Course;
import orm.models.Student;
import orm.repositories.CourseRepository;
import orm.repositories.StudentRepository;

@Service

public class StudentService {

	@Autowired

	private StudentRepository studentRepository;

	@Autowired

	private CourseRepository courseRepository;

	/*
	 * 
	 * @Transactional
	 * 
	 * public void enrollStudentInCourse(Long studentId, Long courseId) {
	 * 
	 * 
	 * 
	 */

	@Transactional

	public void enrollStudentInCourse() {

		// Create and save some students and courses

		Student student1 = new Student();

		student1.setName("Divya");

		Student student2 = new Student();

		student2.setName("Bhavya");

		Course course1 = new Course();

		course1.setTitle("CSE 101");

		Course course2 = new Course();

		course2.setTitle("ECE 101");

		// Student student = studentRepository.findById(studentId).orElseThrow();

		// Course course = courseRepository.findById(courseId).orElseThrow();

		studentRepository.save(student1);

		studentRepository.save(student2);

		courseRepository.save(course1);

		courseRepository.save(course2);

		student1.getCourses().add(course1);

		student2.getCourses().add(course2);

		course1.getStudents().add(student1);

		course2.getStudents().add(student2);

	}

	public List<Student> findAll() {

		return new ArrayList<Student>();

	}

}
