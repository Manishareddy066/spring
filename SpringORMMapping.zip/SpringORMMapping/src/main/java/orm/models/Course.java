package orm.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity

public class Course {

	@Id

	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Long id;

	private String title;

	@ManyToMany(mappedBy = "courses", cascade = { CascadeType.PERSIST, CascadeType.MERGE })

	private Set<Student> students = new HashSet<>();

	// Constructors, getters, and setters

	// Default constructor

	public Course() {

	}

	// Constructor with title

	public Course(String title) {

		this.title = title;

	}

	// Getters and setters

	public Long getId() {

		return id;

	}

	public void setId(Long id) {

		this.id = id;

	}

	public String getTitle() {

		return title;

	}

	public void setTitle(String title) {

		this.title = title;

	}

	public Set<Student> getStudents() {

		return students;

	}

	public void setStudents(Set<Student> students) {

		this.students = students;

	}

}
