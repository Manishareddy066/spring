package springEmp;

import java.util.List;

public interface EmpDAO {

	List<Employee> getAllEmployees();

}
